//*****************************************************************************************************  
// 
//  File:   huffmanstock.cpp 
//   
//  Student:   Admir Bektic 
// 
//  Assignment:   Program  #9 
// 
//  Course Name:  Data Structures II
// 
//  Course Number:  COSC 3100 - 01 
// 
//  Due:   April 9, 2022  
// 
// 
//  This program will define the stock class
// 
//  Other files required:  
//   1. HuffmanStocks.txt   �   text file of stock data 
//   2. stock.cpp  �    definition of the Stock member functions
//	 3. huffmanstock.cpp	-	creates a huffman tree
//   
//***************************************************************************************************** 

#ifndef STOCK_H
#define STOCK_H
#include <string>
#include <iostream>

class Stock
{
	private:
		std::string companyName;
		std::string stockSymbol;
		double price;

	public: //will be defined in Stock.cpp
		Stock(const std::string& = "" , const std::string& = "", double = 0);
		Stock(const Stock&);
		void display() const;
		std::string getName() const;
		std::string getSymbol() const;
		double getPrice() const;
		bool operator==(const Stock&) const;
		bool operator!=(const Stock&) const;
		bool operator<(const Stock&) const;
		bool operator>(const Stock&) const;
		Stock& operator=(const Stock&);
		bool operator>=(const Stock&) const;
		friend std::ostream& operator<<(std::ostream&,const Stock&);
		friend std::istream& operator>>(std::istream&, Stock&);
		int hash(int) const;

};

inline
std::string Stock::getName() const
{
	return companyName; //inline function
}

inline
std::string Stock::getSymbol() const
{
	return stockSymbol; //inline function
}

inline
double Stock::getPrice() const
{
	return price;	//inline function
}

inline
int Stock::hash(int size) const
{
	return size - 1 % 100;
}
#endif
