//*****************************************************************************************************  
// 
//  File:   huffmanstock.cpp 
//   
//  Student:   Admir Bektic 
// 
//  Assignment:   Program  #9 
// 
//  Course Name:  Data Structures II
// 
//  Course Number:  COSC 3100 - 01 
// 
//  Due:   April 9, 2022  
// 
// 
//  This program asks the user to read a file of stocks from a text file and then 
//  creates an tree of stocks by stock frequency.  
// 
//  Other files required:  
//   1. HuffmanStocks.txt   �   text file of stock data 
//   2. stock.h  �    definition of the Stock clas
//	 3. stock.cpp	-	definition of stock member functions
//   
//***************************************************************************************************** 

#include "stock.h"
#include <iostream>
#include <fstream> 
#include <limits>
using namespace std;

template <typename T>
struct Node
{
	double frequency;
	T value;
	Node<T>* left;
	Node<T>* right;
};

int readStocks(const string&, Stock*&, double*&);
int max(int, int);
int min(int, int);
Node<Stock>* createHuffmanTree(Stock [], double [],int);
void printArray(int [], int, Node<Stock>*);
void printPaths(Node<Stock>*, int [], int, int);
void displayStockList(Node<Stock>*, const string&);

int main()
{
	string name = "HuffmanStocks.txt";
	Stock *stocks;
	double *frequency;
	int num = readStocks(name, stocks, frequency);
	int lr = -1;
	int* path = new int[num];
	int zero = 0;
	Node<Stock> * tree;
	string sentence = "00100101100110";

	cout << "there are " << num << " stocks in the file";
	tree = createHuffmanTree(stocks, frequency, num);
	cout << endl << "Here is the tree displayed with the pathes to the nodes";
	cout << endl;
	printPaths(tree, path, zero, lr);
	cout << "Here are the nodes from the path " << sentence << endl;
	displayStockList(tree, sentence);

	delete[] path;
	return 0;
}

//***************************************************************************************************** 

int readStocks(const string& fileName, Stock*& stocks, double*& freqs)
{
	ifstream fin(fileName);
	int numStock;


	if (fin.fail())
	{
		cout << "fail" << endl;
	}
	else
	{
		fin >> numStock;
		stocks = new Stock[numStock];
		freqs = new double[numStock];
		for (int i = 0; i < numStock; i++)
		{
			fin.ignore();
			fin >> stocks[i];
			fin >> freqs[i];
		}
	}

	return numStock;
}

//***************************************************************************************************** 

int max(int index1, int index2)
{
	int max = index1;

	if (index2 > index1)
	{
		max = index2;
	}

	return max;
}

//***************************************************************************************************** 

int min(int index1, int index2)
{
	int min = index1;

	if (index2 < index1)
	{
		min = index2;
	}

	return min;
}

//***************************************************************************************************** 

Node<Stock>* createHuffmanTree(Stock stocks[], double freqs[], int size)
{
	int index1;
	int index2;
	double freq1;
	double freq2;
	Node<Stock>** elements = new Node<Stock>*[size];

	for (int i = 0; i < size; ++i)
	{
		elements[i] = new Node<Stock>;
		elements[i]->value = stocks[i];
		elements[i]->frequency = freqs[i];
		elements[i]->left = nullptr;
		elements[i]->right = nullptr;
	}

	while (size > 1)
	{
		index1 = index2 = 0;
		freq1 = freq2 = numeric_limits<double>::max();
		for (int i = 0; i < size; ++i)
		{
			if (elements[i]->frequency < freq1)
			{
				freq2 = freq1;
				index2 = index1;
				freq1 = elements[i]->frequency;
				index1 = i;
			}
			else if ((elements[i]->frequency < freq2) && (i != index1))
			{
				freq2 = elements[i]->frequency;
				index2 = i;
			}
		}
		Node<Stock>* newNode;
		newNode = new Node<Stock>;
		newNode->left = elements[index1];
		newNode->right = elements[index2];
		newNode->frequency = freq1 + freq2;

		elements[min(index1, index2)] = newNode;
		for (int i = max(index1, index2); i < size - 1; ++i)
		{
			elements[i] = elements[i + 1];
		}

		--size;
	}

	return elements[0];
}

//***************************************************************************************************** 

void printArray(int path[], int pathLen, Node<Stock>* leaf)
{
	cout << leaf->value << "     ";
	for (int i = 0; i < pathLen; i++)
	{
		cout << path[i] << " ";
	}
	cout << endl;
}

//***************************************************************************************************** 

void printPaths(Node<Stock>* node, int path[], int pathLen, int lr)
{
	if (node != nullptr)
	{
		if (lr != -1)
		{
			path[pathLen] = lr;
			++pathLen;
		}
		if ((node->left == nullptr) && (node->right == nullptr))
		{
			printArray(path, pathLen, node);
		}
		else
		{
			printPaths(node->left, path, pathLen, 0);
			printPaths(node->right, path, pathLen, 1);
		}
	}
}

//***************************************************************************************************** 

void displayStockList(Node<Stock>* rootPtr, const string& sentence)
{
	Node<Stock>* root = rootPtr;
	for (int i = 0; i < sentence.length(); i++)
	{
		if (sentence[i] == '0')
		{
			rootPtr = rootPtr->left;
		}
		else
		{
			rootPtr = rootPtr->right;
		}

		if (rootPtr->left == nullptr && rootPtr->right == nullptr)
		{
			cout << rootPtr->value << endl;
			rootPtr = root;
		}
	}
}

/*there are 10 stocks in the file
Here is the tree displayed with the pathes to the nodes
Home Depot Inc HD 279.57     0 0
Coca-Cola Co KO 53.85     0 1 0
Cisco Systems Inc CSCO 42.54     0 1 1 0
Caterpillar Inc CAT 173.19     0 1 1 1 0
Boeing Co BA 202.4     0 1 1 1 1 0
Johnson & Johnson JNJ 150.85     0 1 1 1 1 1
Goldman Sachs Group Inc GS 222.38     1 0
Apple Inc AAPL 120.3     1 1 0
Intel Corp INTC  46.19     1 1 1 0
American Express Co AXP 118.67     1 1 1 1
Here are the nodes from the path 00100101100110
Home Depot Inc HD 279.57
Goldman Sachs Group Inc GS 222.38
Coca-Cola Co KO 53.85
Apple Inc AAPL 120.3
Cisco Systems Inc CSCO 42.54

C:\Users\ninja\source\repos\huffmanstock\Debug\huffmanstock.exe (process 41312) exited with code 0.
Press any key to close this window . . .
*/