//*****************************************************************************************************  
// 
//  File:   huffmanstock.cpp 
//   
//  Student:   Admir Bektic 
// 
//  Assignment:   Program  #9 
// 
//  Course Name:  Data Structures II
// 
//  Course Number:  COSC 3100 - 01 
// 
//  Due:   April 9, 2022  
// 
// 
//  This program will define stock member functions
// 
//  Other files required:  
//   1. HuffmanStocks.txt   �   text file of stock data 
//   2. stock.h  �    definition of the Stock clas
//	 3. huffmanstock.cpp	-	creates a huffman tree
//   
//***************************************************************************************************** 

#include "stock.h"

Stock::Stock(const std::string& name, const std::string& symbol, double cost)
{
	this->companyName = name;
	this->stockSymbol = symbol;
	this->price = cost;
}

Stock::Stock(const Stock& s)
{
	this->companyName = s.companyName;
	this->stockSymbol = s.stockSymbol;
	this->price = s.price;
}

void Stock::display() const
{
	std::cout << "Company Name: " << companyName;
	std::cout << " Stock Symbol: " << stockSymbol;
	std::cout << " Price: " << price;
}

bool Stock::operator==(const Stock& rhs) const
{
	bool status = false;

	if (this->price == rhs.price)
	{
		status = true;
	}

	return status;
}

bool Stock::operator!=(const Stock& rhs) const
{
	bool status = false;

	if (this->price != rhs.price)
	{
		status = true;
	}

	return status;
}

bool Stock::operator<(const Stock& rhs) const
{
	bool status = false;

	if (this->price < rhs.price)
	{
		status = true;
	}

	return status;
}

Stock& Stock::operator=(const Stock& rhs)
{
	if (this != &rhs)
	{
		this->companyName = rhs.companyName;
		this->stockSymbol = rhs.stockSymbol;
		this->price = rhs.price;
	}

	return *this;
}

std::ostream& operator<<(std::ostream& os, const Stock& rhs)
{
	os << rhs.companyName << " " << rhs.stockSymbol << " " << rhs.price;

	return os;
}

std::istream& operator>>(std::istream& in, Stock& rhs)
{
	getline(in, rhs.companyName);
	getline(in, rhs.stockSymbol);
	in >> rhs.price;
	if (!in.eof())
	{
		in.get();
	}


	return in;
}

bool Stock::operator>=(const Stock& s) const
{
	bool status = false;

	if (this->price >= s.price)
	{
		status = true;
	}

	return status;
}

bool Stock::operator>(const Stock& s) const
{
	bool status = false;

	if (this->price > s.price)
	{
		status = true;
	}

	return status;
}