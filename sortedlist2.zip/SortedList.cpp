//*****************************************************************************************************  
// 
//  File:   SortedList.h
//   
//  Student:   Admir Bektic 
// 
//  Assignment:   Program  #10
// 
//  Course Name:  Data Structures II
// 
//  Course Number:  COSC 3100 - 01 
// 
//  Due:   April 18, 2022  
// 
// 
//  This program will read stock data to be sorted.
// 
//  Other files required:  
//   1. sortedList.h	-	defines the sorted list class 
//   2. stock.txt   �   text file of stock data 
//	 3. stock.h  �    definition of the Stock class
//	 4. stock.cpp	-	definition of stock member functions
//   
//***************************************************************************************************** 

#include "stock.h"
#include "SortedList.h"
#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	SortedList<Stock> list;
	Stock stocks;
	ifstream fin("Stock.txt");

	cout << "a list of stocks will be created" << endl;
	while (fin >> stocks)
	{
		list.insert(stocks);
	}
	
	list.display();

	cout << endl << "The list will now be randomized" << endl;
	list.randomise();
	list.display();

	cout << endl << "The list will now be organized in ascending order" << endl;
	list.selectionSortA();
	list.display();

	cout << endl << "The list will now be organized in descending order" << endl;
	list.selectionSortD();
	list.display();

	cout << endl << "The list will now be organized in ascending order quickly" << endl;
	list.quickSortA();
	list.display();

	cout << endl << "The list will now be organized in descending order quickly" << endl;
	list.quickSortD();
	list.display();

	cout << endl << "The list will now be organized in ascending order through heap" << endl;
	list.heapSortA();
	list.display();

	cout << endl << "The list will now be organized in descending order through heap" << endl;
	list.heapSortD();
	list.display();


}

/*a list of stocks will be created
Apple AAPL 121.73
Advanced Micro Devices AMD 84.51
Ford Motor F 11.7
General Electric GE 12.54
Intel INTC 60.78
MINE MI 222
Motorola Inc. MOT 17.49
Tesla TSLA 564.33
Starbucks SBUX 87.45
Amazon AMZN 3295.47
Facebook FB 221.82
AT&T T 23.84
Gamestop GME 151.95
Airbnb ABNB 167.22
AMC AMC 20.24

The list will now be randomized
Amazon AMZN 3295.47
Apple AAPL 121.73
Ford Motor F 11.7
Facebook FB 221.82
Airbnb ABNB 167.22
Advanced Micro Devices AMD 84.51
MINE MI 222
Tesla TSLA 564.33
Motorola Inc. MOT 17.49
AMC AMC 20.24
Intel INTC 60.78
Starbucks SBUX 87.45
Gamestop GME 151.95
General Electric GE 12.54
AT&T T 23.84

The list will now be organized in ascending order
Ford Motor F 11.7
Motorola Inc. MOT 17.49
AT&T T 23.84
General Electric GE 12.54
Intel INTC 60.78
AMC AMC 20.24
Advanced Micro Devices AMD 84.51
Starbucks SBUX 87.45
Apple AAPL 121.73
Gamestop GME 151.95
Airbnb ABNB 167.22
Facebook FB 221.82
Tesla TSLA 564.33
MINE MI 222
Amazon AMZN 3295.47

The list will now be organized in descending order
Amazon AMZN 3295.47
MINE MI 222
Tesla TSLA 564.33
Facebook FB 221.82
Airbnb ABNB 167.22
Gamestop GME 151.95
Apple AAPL 121.73
Starbucks SBUX 87.45
Advanced Micro Devices AMD 84.51
Intel INTC 60.78
AT&T T 23.84
AMC AMC 20.24
Motorola Inc. MOT 17.49
General Electric GE 12.54
Ford Motor F 11.7

The list will now be organized in ascending order quickly
Ford Motor F 11.7
General Electric GE 12.54
Motorola Inc. MOT 17.49
AMC AMC 20.24
AT&T T 23.84
Intel INTC 60.78
Advanced Micro Devices AMD 84.51
Starbucks SBUX 87.45
Apple AAPL 121.73
Gamestop GME 151.95
Airbnb ABNB 167.22
Facebook FB 221.82
MINE MI 222
Tesla TSLA 564.33
Amazon AMZN 3295.47

The list will now be organized in descending order quickly
Amazon AMZN 3295.47
Tesla TSLA 564.33
MINE MI 222
Facebook FB 221.82
Airbnb ABNB 167.22
Gamestop GME 151.95
Apple AAPL 121.73
Starbucks SBUX 87.45
Advanced Micro Devices AMD 84.51
Intel INTC 60.78
AT&T T 23.84
AMC AMC 20.24
Motorola Inc. MOT 17.49
General Electric GE 12.54
Ford Motor F 11.7

The list will now be organized in ascending order through heap
Ford Motor F 11.7
General Electric GE 12.54
Motorola Inc. MOT 17.49
AMC AMC 20.24
AT&T T 23.84
Intel INTC 60.78
Advanced Micro Devices AMD 84.51
Starbucks SBUX 87.45
Apple AAPL 121.73
Gamestop GME 151.95
Airbnb ABNB 167.22
Facebook FB 221.82
MINE MI 222
Tesla TSLA 564.33
Amazon AMZN 3295.47

The list will now be organized in descending order through heap
Amazon AMZN 3295.47
AT&T T 23.84
AMC AMC 20.24
Apple AAPL 121.73
Intel INTC 60.78
Tesla TSLA 564.33
Starbucks SBUX 87.45
General Electric GE 12.54
Gamestop GME 151.95
Airbnb ABNB 167.22
Facebook FB 221.82
MINE MI 222
Advanced Micro Devices AMD 84.51
Motorola Inc. MOT 17.49
Ford Motor F 11.7

C:\Users\ninja\source\repos\sortedlist\Debug\sortedlist.exe (process 38660) exited with code 0.
Press any key to close this window . . .
o close this window . . .
*/