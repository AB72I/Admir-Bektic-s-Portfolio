//*****************************************************************************************************  
// 
//  File:   SortedList.h
//   
//  Student:   Admir Bektic 
// 
//  Assignment:   Program  #10
// 
//  Course Name:  Data Structures II
// 
//  Course Number:  COSC 3100 - 01 
// 
//  Due:   April 18, 2022  
// 
// 
//  This program defines the class SortedList
// 
//  Other files required:  
//   1. stock.txt   �   text file of stock data 
//   2. stock.h  �    definition of the Stock clas
//	 3. stock.cpp	-	definition of stock member functions
//	 4. sortedList.cpp	-	a file that reads stock data to be sorted.
//   
//***************************************************************************************************** 

#ifndef SORTEDLIST_H
#define SORTEDLIST_H
#include <ctime>
#include <cstdlib>

template <typename T>
class SortedList
{
	public:
		SortedList(int = 10);
		~SortedList();
		void insert(const T&);
		void randomise();
		void quickSortA();
		void quickSortD();
		void selectionSortA();
		void selectionSortD();
		void display();
		void heapSortA();
		void heapSortD();

	private:
		T *arr;
		int low = 0;
		int high = numValues - 1;
		int size = 10;
		int numValues;
		int partitionB(T[], int, int);
		int partitionA(T[], int, int);
		void quickSortArecursive(T[], int, int);
		bool isFull() const;
		void quickSortDrecursive(T[], int, int);
		void swap(T&, T&);
		void heapSortARecursive(T[], int);
		void heapifyA(T[], int, int);
		void heapSortDRecursive(T[], int);
		void heapifyD(T[], int, int);
};

//***************************************************************************************************** 

template <typename T>
inline
SortedList<T>::SortedList(int size)
{
	numValues = 0;
	arr = new T[size];
}

//***************************************************************************************************** 

template <typename T>
inline
SortedList<T>::~SortedList()
{
	delete[] arr;
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::swap(T& first, T& second)
{
	T temp;

	temp = first;
	first = second;
	second = temp;
}

//***************************************************************************************************** 

template <typename T>
bool SortedList<T>::isFull() const
{
	bool success = false;

	if (numValues == size)
	{
		success = true;
	}

	return success;
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::insert(const T& item)
{
	T* newArr;

	if (isFull())
	{
		newArr = new T[size + 10];
		size += 10;
		for (int i = 0; i < numValues; i++)
		{
			newArr[i] = arr[i];
		}
		arr = newArr;
	}
	if (numValues < size)
	{
		arr[numValues] = item;
		++numValues;
	}
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::randomise()
{
	short seed = time(0);
	srand(seed);
	T temp;
	int index;

	for (int i = 0; i < numValues; i++)
	{
		index = rand() % numValues;
		temp = arr[index];
		arr[index] = arr[i];
		arr[i] = temp;
	}

}

//***************************************************************************************************** 

template <typename T>
int SortedList<T>::partitionB(T arr[], int low, int high)
{
	T pivot = arr[(low + high) / 2];
	swap(arr[low], arr[(low + high) / 2]);
	int smallIndex = low;
	int index;
	for (int i = low + 1; i <= high; ++i) {
		index = i;
		if (pivot < arr[index]) {
			++smallIndex;
			swap(arr[smallIndex], arr[index]);
		}
	}
	swap(arr[low], arr[smallIndex]);
	return smallIndex;
}

//***************************************************************************************************** 

template <typename T>
int SortedList<T>::partitionA(T arr[], int low, int high)
{
	T pivot = arr[(low + high) / 2];
	swap(arr[low], arr[(low + high) / 2]);
	int smallIndex = low;
	int index;
	for (int i = low + 1; i <= high; ++i) {
		index = i;
		if (pivot > arr[index]) {
			++smallIndex;
			swap(arr[smallIndex], arr[index]);
		}
	}
	swap(arr[low], arr[smallIndex]);
	return smallIndex;
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::quickSortA()
{
	low = 0;
	high = numValues - 1;
	quickSortArecursive(arr, low, high);
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::quickSortArecursive(T arr[], int low, int high)
{
	if(low < high)
	{
		int pivotLoc = partitionA(arr, low, high);
		quickSortArecursive(arr, low, pivotLoc - 1);
		quickSortArecursive(arr, pivotLoc + 1, high);
	}
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::quickSortD()
{
	quickSortDrecursive(arr, low, high);
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::quickSortDrecursive(T arr[], int low, int high)
{
	if (low < high) {
		int pivotLoc = partitionB(arr, low, high);
		quickSortDrecursive(arr, pivotLoc + 1, high);
		quickSortDrecursive(arr, low, pivotLoc - 1);
	}
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::selectionSortA()
{
	T temp;

	for (int i = 0; i < numValues; i++)
	{
		low = i;
		for (int j = i; j < numValues; j++)
		{
			if (arr[j] < arr[low])
			{
				low = j;
			}
			temp = arr[low];
			arr[low] = arr[i];
			arr[i] = temp;
		}
	}
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::selectionSortD()
{
	T temp;

	for (int i = 0; i < numValues; i++)
	{
		low = i;
		for (int j = i; j < numValues; j++)
		{
			if (arr[j] > arr[low])
			{
				low = j;
			}
			temp = arr[low];
			arr[low] = arr[i];
			arr[i] = temp;
		}
	}
}


//***************************************************************************************************** 

template <typename T>
void SortedList<T>::display()
{
	for (int i = 0; i < numValues; i++)
	{
		std::cout << arr[i] << std::endl;
	}
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::heapSortA()
{
	heapSortARecursive(arr, numValues);
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::heapSortARecursive(T arr[], int n)
{
	for (int i = n / 2 - 1; i >= 0; i--) 
	{ 
		heapifyA(arr, n, i);
	}
	for (int i = n - 1; i >= 0; i--)
	{    
		swap(arr[0], arr[i]);
		heapifyA(arr, i, 0);
	}
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::heapifyA(T arr[], int n, int root)
{
	int largest = root;
	int l = 2 * root + 1;
	int r = 2 * root + 2;
 
	if ((l < n) && (arr[l] > arr[largest])) {
		largest = l;
	}

	if ((r < n) && (arr[r] > arr[largest])) {
		largest = r;
	}

	if (largest != root) {

		swap(arr[root], arr[largest]);
		heapifyA(arr, n, largest);
	}
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::heapSortD()
{
	heapSortDRecursive(arr, numValues);
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::heapSortDRecursive(T arr[], int n)
{
	for (int i = n / 2 - 1; i >= 0; i--)
	{
		heapifyD(arr, n, i);
	}
	for (int i = n - 1; i >= 0; i--)
	{
		swap(arr[0], arr[i]);
		heapifyD(arr, i, 0);
	}
}

//***************************************************************************************************** 

template <typename T>
void SortedList<T>::heapifyD(T arr[], int n, int root)
{
	int largest = root;
	int l = 2 * root + 1;
	int r = 2 * root + 2;

	if ((l > n) && (arr[l] > arr[largest])) {
		largest = l;
	}

	if ((r < n) && (arr[r] < arr[largest])) {
		largest = r;
	}

	if (largest != root) {

		swap(arr[root], arr[largest]);
		heapifyD(arr, n, largest);
	}
}
#endif