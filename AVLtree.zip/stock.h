#ifndef STOCK_H
#define STOCK_H
#include <string>
#include <iostream>

class Stock
{
	private:
		std::string companyName;
		std::string stockSymbol;
		double price;

	public: //will be defined in Stock.cpp
		Stock(const std::string& = "" , const std::string& = "", double = 0);
		Stock(const Stock&);
		void display() const;
		std::string getName() const;
		std::string getSymbol() const;
		double getPrice() const;
		bool operator==(const Stock&) const;
		bool operator!=(const Stock&) const;
		bool operator<(const Stock&) const;
		bool operator>(const Stock&) const;
		Stock& operator=(const Stock&);
		bool operator>=(const Stock&) const;
		friend std::ostream& operator<<(std::ostream&,const Stock&);
		friend std::istream& operator>>(std::istream&, Stock&);
		int hash(int) const;

};
#endif
