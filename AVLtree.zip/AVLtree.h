#ifndef AVLTREE_H
#define AVLTREE_H

template <typename T>
struct Node
{
	T value;
	int bFactor; // Balance Factor 
	Node<T>* left;
	Node<T>* right;
};

//***************************************************************************************************** 

template <typename T>
class Avltree
{
public:
	Avltree();
	~Avltree();
	void insert(const T& item);
	void inorder() const;
	void destroy();
	void preorder() const;
	void postorder() const;
	int max(int a, int b) const;
	T* search(const T& item) const;
	int height() const;

private:
	Node<T> * root;
	void rotateLeft(Node<T>*&);
	void rotateRight(Node<T>*&);
	int getBalance(Node<T>*) const;
	void updatebFactors(Node<T>* r);
	void insertRecursive(Node<T>*& r, const T& item);
	void deleteTree(Node<T>*&);
	void inorderRecursive(Node<T>*) const;
	void preorderRecursive(Node<T>*) const;
	void postorderRecursive(Node<T>*) const;
	int heightRecursive(Node<T>*) const;
	T* searchRecursive(Node<T>*, const T& item) const;
};

//***************************************************************************************************** 

template <typename T>
Avltree<T>::Avltree()
{
	root = nullptr;
}

//***************************************************************************************************** 

template <typename T>
Avltree<T>::~Avltree()
{
	destroy();
}

//***************************************************************************************************** 

template <typename T>
void Avltree<T>::rotateLeft(Node<T>*& k1)
{
	Node<T>* k2 = k1->right;
	k1->right = k2->left;
	k2->left = k1;
	k1 = k2;
}

//***************************************************************************************************** 

template <typename T>
void Avltree<T>::rotateRight(Node<T>*& k1)
{
	Node<T>* k2 = k1->left;
	k1->left = k2->right;
	k2->right = k1;
	k1 = k2;
}

//***************************************************************************************************** 

template <typename T>
int Avltree<T>::getBalance(Node<T>* r) const
{
	int balance;
	if (r == nullptr) {
		balance = 0;
	}
	else {
		balance = heightRecursive(r->left) - heightRecursive(r->right);
	}
	return balance;
}

//***************************************************************************************************** 

template <typename T>
void Avltree<T>::updatebFactors(Node<T>* r)
{
	if (r != nullptr) {
		r->bFactor = getBalance(r);
		updatebFactors(r->left);
		updatebFactors(r->right);
	}
}

//***************************************************************************************************** 

template <typename T>
void Avltree<T>::insertRecursive(Node<T>*& r, const T& item)
{
	if (r == nullptr) {
		r = new Node<T>;
		r->value = item;
		r->left = nullptr;
		r->right = nullptr;
	}
	else {
		if (item < r->value) {
			insertRecursive(r->left, item);
		}
		else {
			insertRecursive(r->right, item);
		}
	}

	r->bFactor = getBalance(r);




	if (r->bFactor > 1) {
		if (r->left->bFactor > 0) {
			rotateRight(r);
		}
		else {
			rotateLeft(r->left);
			rotateRight(r);
		}
		updatebFactors(r);
	}
	else if (r->bFactor < -1) {
		if (r->right->bFactor < 0) {
			rotateLeft(r);
		}
		else {
			rotateRight(r->right);
			rotateLeft(r);
		}
		updatebFactors(r);
	}
}

//***************************************************************************************************** 

template <typename T>
void Avltree<T>::insert(const T& item)
{
	insertRecursive(root, item);
};

//*****************************************************************************************************

template <typename T>
void Avltree<T>::destroy()
{
	deleteTree(root);
};

//*****************************************************************************************************

template <typename T>
void Avltree<T>::deleteTree(Node<T>*& r)
{
	if (r != nullptr) {
		deleteTree(r->left);
		deleteTree(r->right);
		delete r;
		r = nullptr;
	}
}

//*****************************************************************************************************

template <typename T>
void Avltree<T>::inorder() const
{
	inorderRecursive(root);
}

//***************************************************************************************************** 

template <typename T>
void  Avltree<T>::inorderRecursive(Node<T>* root) const
{
	if (root != nullptr)
	{
		inorderRecursive(root->left);
		std::cout << root->value << " balance factor: " << root->bFactor << std::endl << std::endl;
		inorderRecursive(root->right);
	}
}

//***************************************************************************************************** 

template <typename T>
void Avltree<T>::preorder() const
{
	preorderRecursive(root);
}

//***************************************************************************************************** 

template <typename T>
void Avltree<T>::preorderRecursive(Node<T>* root) const
{
	if (root != nullptr)
	{
		std::cout << root->value << " balance factor: " << root->bFactor << std::endl << std::endl;
		preorderRecursive(root->left);
		preorderRecursive(root->right);
	}
}

//***************************************************************************************************** 

template <typename T>
void Avltree<T>::postorder() const
{
	postorderRecursive(root);
}

//***************************************************************************************************** 

template <typename T>
void Avltree<T>::postorderRecursive(Node<T>* root) const
{
	if (root != nullptr)
	{
		postorderRecursive(root->left);
		postorderRecursive(root->right);
		std::cout << root->value << " balance factor: " << root->bFactor << std::endl << std::endl;
	}
}

//***************************************************************************************************** 

template <typename T>
int Avltree<T>::max(int a, int b) const
{
	return (a > b) ? a : b;
}

//***************************************************************************************************** 

template <typename T>
int Avltree<T>::heightRecursive(Node<T>* root) const
{
	if (root == nullptr)
	{
		return 0;
	}
	else
	{
		return 1 + max(heightRecursive(root->left), heightRecursive(root->right));
	}
}

//***************************************************************************************************** 

template <typename T>
int Avltree<T>::height() const
{
	return heightRecursive(root);
}

//***************************************************************************************************** 

template <typename T>
T* Avltree<T>::searchRecursive(Node<T>* root, const T& item) const
{
	T* result;
	if (root == nullptr)
	{
		result = nullptr;
	}
	else if (item < root->value)
	{
		result = searchRecursive(root->left, item);
	}
	else if (root->value < item)
	{
		result = searchRecursive(root->right, item);
	}
	else
	{
		result = new T(root->value);
	}
	return result;
}

//***************************************************************************************************** 

template <typename T>
T* Avltree<T>::search(const T& item) const
{
	return searchRecursive(root, item);
}
#endif
