#include "stock.h"

Stock::Stock(const std::string& name, const std::string& symbol, double cost)
{
	this->companyName = name;
	this->stockSymbol = symbol;
	this->price = cost;
}

Stock::Stock(const Stock& s)
{
	this->companyName = s.companyName;
	this->stockSymbol = s.stockSymbol;
	this->price = s.price;
}

void Stock::display() const
{
	std::cout << "Company Name: " << companyName;
	std::cout << " Stock Symbol: " << stockSymbol;
	std::cout << " Price: " << price;
}

inline
std::string Stock::getName() const
{
	return companyName; //inline function
}

inline
std::string Stock::getSymbol() const
{
	return stockSymbol; //inline function
}

inline
double Stock::getPrice() const
{
	return price;	//inline function
}

bool Stock::operator==(const Stock& rhs) const
{
	bool status = false;

	if (this->price == rhs.price)
	{
		status = true;
	}

	return status;
}

bool Stock::operator!=(const Stock& rhs) const
{
	bool status = false;

	if (this->price != rhs.price)
	{
		status = true;
	}

	return status;
}

bool Stock::operator<(const Stock& rhs) const
{
	bool status = false;

	if (this->price < rhs.price)
	{
		status = true;
	}

	return status;
}

Stock& Stock::operator=(const Stock& rhs)
{
	if (this != &rhs)
	{
		this->companyName = rhs.companyName;
		this->stockSymbol = rhs.stockSymbol;
		this->price = rhs.price;
	}

	return *this;
}

std::ostream& operator<<(std::ostream& os, const Stock& rhs)
{
	os << rhs.companyName << " " << rhs.stockSymbol << " " << rhs.price;

	return os;
}

std::istream& operator>>(std::istream& in, Stock& rhs)
{
	getline(in, rhs.companyName);
	getline(in, rhs.stockSymbol);
	in >> rhs.price;
	if (!in.eof())
	{
		in.get();
	}


	return in;
}


inline
int Stock::hash(int size) const
{
	return size - 1 % 100;
}

bool Stock::operator>=(const Stock& s) const
{
	bool status = false;

	if (this->price >= s.price)
	{
		status = true;
	}

	return status;
}

bool Stock::operator>(const Stock& s) const
{
	bool status = false;

	if (this->price > s.price)
	{
		status = true;
	}

	return status;
}