#include "AVLtree.h"
#include "stock.h"
#include <iostream>
using namespace std;

int main()
{
	Stock stock1 = {"Apple", "AAPL", 121.73}, //individual stock objects created due to
		  stock2 = { "Advanced Micro Devices", "AMD", 84.51 },	//there being no method of
		  stock3 = { "Ford Motor", "F", 11.7 }, //inputing user data
		  stock4 = { "General Electric", "GE", 12.54 },
		  stock5 = { "Intel", "INTC", 60.78 },
		  stock6 = { "MINE", "MI", 222 },
		  stock7 = { "Motorola Inc.", "MOT", 17.49 },
		  stock8 = { "Tesla", "TSLA", 564.33 },
		  stock9 = { "Starbucks", "SBUX", 87.45 },
		  stock10 = { "Amazon", "AMZN", 3295.47 };
	Stock * sptr;
	Avltree<Stock> tree;

	cout << "Stocks will be inserted into the avl tree" << endl;

	tree.insert(stock1);
	tree.insert(stock2);
	tree.insert(stock3);
	tree.insert(stock4);
	tree.insert(stock5);
	tree.insert(stock6);
	tree.insert(stock7);
	tree.insert(stock8);
	tree.insert(stock9);
	tree.insert(stock10);

	cout << "The Tree inorder" << endl;
	tree.inorder();

	cout << "The Tree preorder" << endl;
	tree.preorder();

	cout << "The Tree postorder" << endl;
	tree.postorder();

	cout << "The height of the tree is " << tree.height();

	cout << "we will now search for stock5" << endl;
	sptr = tree.search(stock5);

	if (sptr == nullptr)
	{
		cout << "stock5 has not been found" << endl;
	}
	else
	{
		cout << "stock5 has been found" << endl;
	}

	return 0;
}

/*
Stocks will be inserted into the avl tree
The Tree inorder
Ford Motor F 11.7 balance factor : 0

General Electric GE 12.54 balance factor : -1

Motorola Inc.MOT 17.49 balance factor : 0

Intel INTC 60.78 balance factor : 1

Advanced Micro Devices AMD 84.51 balance factor : 0

Starbucks SBUX 87.45 balance factor : 0

Apple AAPL 121.73 balance factor : 1

MINE MI 222 balance factor : 0

Tesla TSLA 564.33 balance factor : -1

Amazon AMZN 3295.47 balance factor : 0

The Tree preorder
Advanced Micro Devices AMD 84.51 balance factor : 0

General Electric GE 12.54 balance factor : -1

Ford Motor F 11.7 balance factor : 0

Intel INTC 60.78 balance factor : 1

Motorola Inc.MOT 17.49 balance factor : 0

MINE MI 222 balance factor : 0

Apple AAPL 121.73 balance factor : 1

Starbucks SBUX 87.45 balance factor : 0

Tesla TSLA 564.33 balance factor : -1

Amazon AMZN 3295.47 balance factor : 0

The Tree postorder
Ford Motor F 11.7 balance factor : 0

Motorola Inc.MOT 17.49 balance factor : 0

Intel INTC 60.78 balance factor : 1

General Electric GE 12.54 balance factor : -1

Starbucks SBUX 87.45 balance factor : 0

Apple AAPL 121.73 balance factor : 1

Amazon AMZN 3295.47 balance factor : 0

Tesla TSLA 564.33 balance factor : -1

MINE MI 222 balance factor : 0

Advanced Micro Devices AMD 84.51 balance factor : 0

The height of the tree is 4we will now search for stock5
stock5 has been found

C : \Users\ninja\source\repos\Project1\Debug\Project1.exe(process 19184) exited with code 0.
	Press any key to close this window . . .
*/